#!/usr/bin/env python3
# Copyright (C) 2024 Efabless Corporation
#
# Permission to use, copy, modify, and/or distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""
This runs the cibuildwheel step from the wheels workflow locally.
"""

import os
import yaml
import platform
import subprocess
from pathlib import Path

__yosys_root__ = Path(__file__).absolute().parents[3]

for source in ["ffi", "bison"]:
    if not (__yosys_root__ / source).is_dir():
        print(
            "You need to download ffi and bison in a similar manner to wheels.yml first."
        )
        exit(-1)

with open(__yosys_root__ / ".github" / "workflows" / "wheels.yml") as f:
    workflow = yaml.safe_load(f)

env = os.environ.copy()

steps = workflow["jobs"]["build_wheels"]["steps"]
cibw_step = None
for step in steps:
    if (step.get("uses") or "").startswith("pypa/cibuildwheel"):
        cibw_step = step
        break

for key, value in cibw_step["env"].items():
    if key.endswith("WIN") or key.endswith("MAC"):
        continue
    env[key] = value

env["CIBW_ARCHS"] = os.getenv("CIBW_ARCHS", platform.machine())
subprocess.check_call(["cibuildwheel"], env=env)
