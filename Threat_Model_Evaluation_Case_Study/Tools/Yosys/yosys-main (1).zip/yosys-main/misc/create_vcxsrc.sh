#!/usr/bin/env bash

set -ex
vcxsrc="$1"
yosysver="$2"

rm -rf YosysVS-Tpl-v2.zip YosysVS
wget https://github.com/YosysHQ/yosys/releases/download/resources/YosysVS-Tpl-v2.zip
wget https://github.com/YosysHQ/yosys/releases/download/resources/zlib-1.2.11.tar.gz

unzip YosysVS-Tpl-v2.zip
rm -f YosysVS-Tpl-v2.zip
tar xvfz zlib-1.2.11.tar.gz

mv YosysVS "$vcxsrc"
mkdir -p "$vcxsrc"/yosys
mkdir -p "$vcxsrc"/yosys/libs/zlib
mv zlib-1.2.11/* "$vcxsrc"/yosys/libs/zlib/.
rm -rf zlib-1.2.11
pushd "$vcxsrc"/yosys
ls libs/zlib/*.c | sed 's,.*:,,; s,//*,/,g; s,/[^/]*/\.\./,/,g; y, \\,\n\n,;' | grep '^[^/]'  >> ../../srcfiles.txt

if [ -f "/usr/include/FlexLexer.h" ] ; then
	mkdir -p libs/flex
	cp /usr/include/FlexLexer.h libs/flex/FlexLexer.h
	ls libs/flex/*.h >> ../../srcfiles.txt
fi

popd
{
	n=$(grep -B999 '<ItemGroup>' "$vcxsrc"/YosysVS/YosysVS.vcxproj | wc -l)
	head -n$n "$vcxsrc"/YosysVS/YosysVS.vcxproj
	egrep '\.(h|hh|hpp|inc)$' srcfiles.txt | sed 's,.*,<ClInclude Include="../yosys/&" />,'
	egrep -v '\.(h|hh|hpp|inc)$' srcfiles.txt | sed 's,.*,<ClCompile Include="../yosys/&" />,'
	tail -n +$((n+1)) "$vcxsrc"/YosysVS/YosysVS.vcxproj
} > "$vcxsrc"/YosysVS/YosysVS.vcxproj.new

sed -i 's,</AdditionalIncludeDirectories>,</AdditionalIncludeDirectories>\n      <LanguageStandard>stdcpp17</LanguageStandard>\n      <AdditionalOptions>/Zc:__cplusplus %(AdditionalOptions)</AdditionalOptions>,g' "$vcxsrc"/YosysVS/YosysVS.vcxproj.new
sed -i 's,<PreprocessorDefinitions>,<PreprocessorDefinitions>YOSYS_ENABLE_THREADS;,g' "$vcxsrc"/YosysVS/YosysVS.vcxproj.new
if [ -f "/usr/include/FlexLexer.h" ] ; then
	sed -i 's,</AdditionalIncludeDirectories>,;..\\yosys\\libs\\flex</AdditionalIncludeDirectories>,g' "$vcxsrc"/YosysVS/YosysVS.vcxproj.new
fi
mv "$vcxsrc"/YosysVS/YosysVS.vcxproj.new "$vcxsrc"/YosysVS/YosysVS.vcxproj

mkdir -p "$vcxsrc"/yosys
tar -cf - -T srcfiles.txt | tar -xf - -C "$vcxsrc"/yosys
cp -r share "$vcxsrc"/

cat > "$vcxsrc"/readme-git.txt << EOT
Want to use a git working copy for the yosys source code?
Open "Git Bash" in this directory and run:

	mv yosys yosys.bak
	git clone https://github.com/YosysHQ/yosys.git yosys
	cd yosys
	git checkout -B main $(git rev-parse HEAD | cut -c1-10)
	unzip ../genfiles.zip
EOT

cat > "$vcxsrc"/readme-abc.txt << EOT
Yosys is using "ABC" for gate-level optimizations and technology
mapping. Download yosys-win32-mxebin-$yosysver.zip and copy the
following files from it into this directory:

	pthreadVC2.dll
	yosys-abc.exe
EOT

sed -i 's/$/\r/; s/\r\r*/\r/g;' "$vcxsrc"/YosysVS/YosysVS.vcxproj "$vcxsrc"/readme-git.txt "$vcxsrc"/readme-abc.txt

